from flask import Flask, render_template, request, send_file
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Configurar el backend de Matplotlib para evitar GUI
import matplotlib.pyplot as plt
import seaborn as sns
import os
import numpy as np
import pdfkit

app = Flask(__name__)

# Función para cargar los datos según la región
def load_data(region, reino=None):
    if region == 'Cundinamarca':
        df = pd.read_csv('Cundinamarca.csv')
    elif region == 'Boyacá':
        df = pd.read_csv('Boyaca.csv')
    else:
        return pd.DataFrame()  # Retornar DataFrame vacío si no se selecciona región
    
    df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
    
    if reino:
        df = df[df['Reino'] == reino]  # Filtrar por el reino seleccionado

   # Identificar las columnas que contienen los enlaces
    if 'GBIF' in df.columns and 'CBC' in df.columns:  
        df['GBIF'] = df['GBIF'].apply(lambda x: f'<a href="{x}" target="_blank">GBIF</a>')
        df['CBC'] = df['CBC'].apply(lambda x: f'<a href="{x}" target="_blank">CBC</a>')
    
    return df

# Función para calcular estadísticas con NumPy
def calculate_statistics(df):
    registros = df['Registros'].to_numpy()  # Convertir la columna de registros a un array de NumPy
    total_registros = np.sum(registros)  # Sumar todos los registros
    media_registros = np.mean(registros)  # Calcular la media
    max_registros = np.max(registros)  # Obtener el valor máximo
    min_registros = np.min(registros)  # Obtener el valor mínimo

    return {
        'total': total_registros,
        'media': media_registros,
        'max': max_registros,
        'min': min_registros
    }

# Función para generar el gráfico de Matplotlib (top 5 especies con más registros)
def plot_top_species(df, region, reino):
    top_species = df.groupby('Especie')['Registros'].sum().nlargest(5).reset_index()

    plt.figure(figsize=(8, 5))
    ax = sns.barplot(x='Registros', y='Especie', data=top_species, palette='viridis')

    plt.title(f'Top 5 especies en {region} del reino {reino}', fontsize=16)
    plt.xlabel('Número de Registros', fontsize=14)
    plt.ylabel('Especie', fontsize=14)

    # Mostrar el total de registros sobre cada barra
    for index, value in enumerate(top_species['Registros']):
        ax.text(value, index, f'{int(value)}', color='black', va="center", fontsize=12)

    plt.tight_layout()

    # Guardar el gráfico como imagen
    plot_path = os.path.join('static', 'top_species.png')
    plt.savefig(plot_path)
    plt.close()

    return plot_path

# Especificar la ruta de wkhtmltopdf si es necesario
path_to_wkhtmltopdf = r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe'  
config = pdfkit.configuration(wkhtmltopdf=path_to_wkhtmltopdf)

# Ruta principal para mostrar la tabla y gráficos
@app.route('/explorador', methods=['GET'])
def explorador():
    region = request.args.get('region', 'Cundinamarca')  # Cundinamarca como valor por defecto
    reino = request.args.get('reino', None)  # Filtrado opcional por reino

    data = load_data(region, reino)

    table_html = data.to_html(classes='table table-striped', index=False, escape=False) if not data.empty else "No data available"

    plot_path = None
    if not data.empty:
        plot_path = plot_top_species(data, region, reino)

    stats = None
    if not data.empty:
        stats = calculate_statistics(data)

    pie_chart_path = None
    if not data.empty:
        data_region_only = load_data(region)
        pie_chart_path = f'static/pie_chart_{region.lower()}.png'  # Ruta de la imagen según la región

    return render_template('explorador.html', table_html=table_html, region=region, reino=reino, stats=stats, plot_path=plot_path, pie_chart_path=pie_chart_path)

# Ruta para generar el PDF basado en los resultados filtrados
@app.route('/generate_pdf', methods=['GET'])
def generate_pdf():
    region = request.args.get('region', 'Cundinamarca')
    reino = request.args.get('reino', None)

    data = load_data(region, reino)

    table_html = data.to_html(classes='table table-striped', index=False, escape=False) if not data.empty else "No data available"

    # Seleccionar la imagen de la gráfica de torta según la región
    pie_chart_image = os.path.abspath(os.path.join('static', f'pie_chart_{region.lower()}.png'))

    # Generar la gráfica de barras y obtener la ruta
    bar_chart_path = None
    if not data.empty:
        bar_chart_path = os.path.abspath(plot_top_species(data, region, reino))  # Obtener la ruta absoluta

    # Calcular estadísticas
    stats = calculate_statistics(data) if not data.empty else None

    # Renderizar el HTML con las variables
    rendered_html = render_template(
        'pdf_template.html',
        table_html=table_html,
        region=region,
        reino=reino,
        pie_chart_image=pie_chart_image,
        bar_chart_path=bar_chart_path,
        stats=stats
    )

    options = {
        'page-size': 'Letter',
        'encoding': 'UTF-8',
        'enable-local-file-access': ''
    }
    # Usar la configuración que incluye la ruta de wkhtmltopdf
    pdf = pdfkit.from_string(rendered_html, False, options=options, configuration=config)

    pdf_path = 'filtered_results.pdf'
    with open(pdf_path, 'wb') as f:
        f.write(pdf)

    return send_file(pdf_path, as_attachment=True, download_name=f'{region}_{reino}_biodiversidad.pdf')

if __name__ == '__main__':
    app.run(debug=True)

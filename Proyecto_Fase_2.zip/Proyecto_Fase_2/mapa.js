var map = L.map('map').setView([4.5709, -74.2973], 7); 


L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);


var parques = [
    {
        name: "Parque Nacional Natural El Cocuy",
        coords: [6.4062, -72.2926],
        url: "https://www.parquesnacionales.gov.co/nuestros-parques/pnn-el-cocuy/"      },
    {
        name: "Santuario de Fauna y Flora Iguaque",
        coords: [5.7006, -73.4338],
        url: "https://www.parquesnacionales.gov.co/nuestros-parques/sff-iguaque/"  
    },
    {
        name: "Parque Natural Regional Serranía de las Quinchas",
        coords: [5.6932, -74.1666],
        url: "https://www.corpoboyaca.gov.co/sirap/areas-protegidas/regionales/parque-natural-regional-serrania-de-las-quinchas/"  
    },
    {
        name: "Parque Natural Regional Corredor Biológico Guantiva - La Rusia",
        coords: [6.0000, -72.9000],
        url: "https://www.corpoboyaca.gov.co/sirap/areas-protegidas/"  
    },
    {
        name: "Parque Nacional Natural Chingaza",
        coords: [4.6840, -73.8157],
        url: "https://old.parquesnacionales.gov.co/portal/es/ecoturismo/parques/region-amazonia-y-orinoquia/parque-nacional-natural-chingaza/"  
    },
    {
        name: "Parque Nacional Natural Sumapaz",
        coords: [4.2091, -74.1746],
        url: "https://www.parquesnacionales.gov.co/nuestros-parques/pnn-sumapaz/"  
    },
    {
        name: "Parque Natural Regional Embalse del Neusa",
        coords: [5.1296, -73.9966],
        url: "http://www.colparques.net/NEUSA"  
        },
    {
        name: "Parque Natural Chicaque",
        coords: [4.5944, -74.3196],
        url: "https://www.chicaque.com/"  
    },
    {
        name: "Parque Natural La Chorrera",
        coords: [4.5111, -74.1781],
        url: "https://lachorrera.com.co/"  
    }
];


parques.forEach(function(parque) {
    L.marker(parque.coords).addTo(map)
        .bindPopup('<b>' + parque.name + '</b><br><a href="' + parque.url + '" target="_blank">Más información</a>');
});

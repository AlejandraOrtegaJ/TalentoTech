from flask import Flask, render_template, jsonify
import requests
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Permitir solicitudes CORS

@app.route('/explorador')
def inicio():
    return render_template('explorador.html')

@app.route('/biodiversidad/<region>')
def obtener_biodiversidad(region):
    datos = obtener_datos_biodiversidad(region)
    return jsonify(datos)

def obtener_datos_biodiversidad(region):
    url = f"https://api.gbif.org/v1/occurrence/search?country=CO&stateProvince={region}&limit=100"
    response = requests.get(url)
    return response.json()

if __name__ == '__main__':
    app.run(debug=True)
